package com.example.bojan.locationdemo_uvod;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //todo I Defininisanje permissions i features u Manifest file
    //todo II potrebna je klasa LocationManager-omogucava pristup sistemskim servisima za rukovanje podacima o lokaciji ...
    //todo ... i interface LocationListener koji ce nam biti potreba pri vrsenju pretplate na dobijanje podataka

    //todo Variables and const
    LocationManager locationManager;
    //locationListener je potrebno kreirati anonimnu klasu jer je interface
    LocationListener locationListener;
    //konstanta ciju vrednost koristimo kako bi identifikovali odgovor koji dobijamo od korisnika
    static final int MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATIONS = 1;

    TextView textView;

//todo -------------------------------------------pocetak onCreate Metode------------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textViewID);

        //todo III
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        //todo IV kreiranje anonimne klase LocationListener
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                displayNewLocationData(location);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        };

        registerLocationUpdates();

    }//todo ---------------------------------------------------kraj onCreate Metode--------------------------------------------------------


    //todo --------VIII definisanje logike kojom cemo obraditi odgovor koji cemo dobiti od korisnika na tra\enje dozvole (stepVII)------
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATIONS: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    //dobijena dozvola
                    registerLocationUpdates();
                } else {
                    //odbijena dozvola
                    Toast.makeText(this, "Location can't bew determinated", Toast.LENGTH_LONG).show();
                }
                break;
            }
        }

    }
    //todo ------------------- kraj metode onRequestPermissionsResult-----------------------------------------------------------------------
    //-------------
    //todo IX metoda kojim definisemo prikaz podataka o lokaciji, treba je pozvati u onLocationChanged metodi
    private void displayNewLocationData(Location location){

        String lat = String.valueOf(location.getLatitude());
        String lng = String.valueOf(location.getLongitude());
        Log.e("LOKACIJA", lat+" "+lng);
        String provider = String.valueOf(location.getProvider());

        textView.setText("Latitude: "+lat+"\nlongitude: "+lng+"\nProvider: "+provider);

    }

    //todo X zasebna metoda za proveru posedovanja doyvole----------------!!!!! ovo je na pocetku stajalo u onCreate metode, sada je potrebno da se umesto logike koja je stajala na kraju...
    // todo ...onCreate postavi ova metoda ali i u metodu onRequestPermissionsResult u if delu gde je slucaj dobijanja dozvole.
    private void registerLocationUpdates(){
        //todo VI Provera za posedovanje dozvole ACCESS_FINE_LOCATION potrebno je da se smesti u zasebnu metodu kako bi bila globalno dostupna
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){

            //todo  V vrsenje pretplate na dobijanje podataka o lokaciji nad objektom listionManager
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);

        }else {
            //todo VII ukoliko aplikacije ne poseduje doyvolu od korisnika cemo traziti dozvolu
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATIONS);

        }
    }
    //todo -----------------------------------------------------------kraj X metode--------------------------------------------------------------------
}
